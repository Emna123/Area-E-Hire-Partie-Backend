﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicationTEST.Models
{
    public class Response
    {
        public string message { get; set; }
        public string status { get; set; }
        public string extrafield { get; set; }

    }
}
